# resk-discovery

#### 介绍
eureka 服务发现

 
## 运行

> 
> mvn clean install

> cd target
> 

> PID_FOLDER="/var/run"
> 
> LOG_FOLDER="/var/log"

> ./resk-discovery-1.0-exec.jar run|start|stop|restart
