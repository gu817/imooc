package main

import (
	"fmt"
	"git.imooc.com/wendell1000/infra/algo"
)

func main() {
	fmt.Println(algo.AfterShuffle(int64(10), int64(10000)))
}
